sudo yum install python3-dns python3-netaddr

